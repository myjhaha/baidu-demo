
/*
var node = {
  value:125,
  left:null,
  right:null
};
*/
function Node(val) {
    this.value = val;
    this.parent = null;
    this.left = null;
    this.right = null;
}
function BinarySearchTree(){
  this._root = null;
}
BinarySearchTree.prototype = {
  constructor: BinarySearchTree,
  add: function(value){
  },
  remove: function(value){

  },
  contains: function(value){

  },
  traverse: function(process){
    // helper function
    function inOrder(node){
      if(node){
        if(node.left !== null){
          inOrder(node.left);
        }
        process.call(this,node);
        if(node.right !== null){
          inOrder(node.right);
        }
      }
    }
    inOrder(this._root);
  },
  size: function(){
    var len = 0;
    this.traverse(function(node){
      len ++ ;
    });
    return len;
  },
  toArray:function(){
    var arr = [];
    this.traverse(function(node){
      arr.push(node.value);
    });
    return arr;
  },
  toString: function(){
    return this.toArray().toString();
  }
}
BinarySearchTree.prototype.add = function(value){
  var current;
  var node = {  value: value,
                left: null,
                right: null,
                parent: null };
  if(this._root === null){
    this._root = node;
  }else{
    current = this._root;
    while(true){
      if(value < current.value){
        if(current.left === null){
          node.parent = current;
          current.left = node;
          break;
        }else{
          current = current.left;
          continue;
        }
      }else if(value > current.value){
        if(current.right === null){
          node.parent = current;
          current.right = node;
          break;
        }else{
          current = current.right;
          continue;
        }
      }else{ //value === current.value
        break;
      }
    }
  }
}
BinarySearchTree.prototype.remove = function(value){
  
}


window.onload = function(){
  var bst = new BinarySearchTree();
  bst.add(15);
  bst.add(4);
  bst.add(2);
  bst.add(3);
  bst.add(18);
  bst.add(16);
  bst.add(19);
  console.log(bst.toArray());
  console.log(bst.size());
}