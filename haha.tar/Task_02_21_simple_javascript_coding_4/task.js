function TagShow(){
	var o = new Object();

	o.inputTarget = null;
	o.renderTarget = null;
	o.queueData = [];
	o.pushTag = function(tag){
		if (tag && tag != "") {
			o.queueData.push(tag.trim());
		};
	}; 
	o.splice = function(index){
		return o.queueData.splice(index,1);
	};
	o.render = function(){
		var str = "";
		o.queueData.filter(function(e){return (e && e != "");}).map(function(e){
			str += ( "<div class=\"list-div\">" + e + "</div>" );
		});
		o.renderTarget.innerHTML = str;
	}
	
	o.init = function(_inputTarget, _renderTarget){
		console.log(o);
		o.inputTarget = _inputTarget;
		o.renderTarget = _renderTarget;
		addEventHandler(o.inputTarget, "change", inputTxtChange);
		// test
		this.queueData.push("ab");
		this.queueData.push("abcdc");
	};
	function inputTxtChange (){
		console.log(o);
		console.log(o.inputTarget.value);
	};
	return o;
}
 
/**
 * page 
 */
var intpuTxt1;
var intpuTxt2;
var intpuTxt3;
var tagContainer1;
var tagContainer2;
var tagContainer3;
var commitBtn;
/**
 * 事件插入浏览器兼容
 */
function addEventHandler(element, ev, handler){
  if(element.addEventListener){
    element.addEventListener(ev,handler,false);
  }else if(element.attachEvent){
    element.attachEvent("on" + ev, handler);
  }else{
    element["on" + ev] = handler;
  }
}

var t1 = TagShow();

function initPageEvent(){
	intpuTxt1 = intpuTxt1 || document.getElementById("input-text-1");
	intpuTxt2 = intpuTxt2 || document.getElementById("input-text-2");
	intpuTxt3 = intpuTxt3 || document.getElementById("input-text-3");
	tagContainer1 = tagContainer1 || document.getElementById("tag-container-1");
	tagContainer2 = tagContainer2 || document.getElementById("tag-container-2");
	tagContainer3 = tagContainer3 || document.getElementById("tag-container-3");
	commitBtn = commitBtn || document.getElementById("commit-btn");

	
}

function renderChart(){
	t1.render();
}

window.onload = function(){
	initPageEvent();
	t1.init(intpuTxt1,tagContainer1);
	renderChart();
}